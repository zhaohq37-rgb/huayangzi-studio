const UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const LOWER = "abcdefghijklmnopqrstuvwxyz";
const DIGITS = "0123456789";

function makeMap(upper = UPPER, lower = LOWER, digits = DIGITS) {
  const upperChars = [...upper];
  const lowerChars = [...lower];
  const digitChars = [...digits];
  if (upperChars.length !== 26 || lowerChars.length !== 26 || digitChars.length !== 10) {
    throw new Error("花字映射表长度不完整");
  }
  const map = new Map();
  [...UPPER].forEach((char, index) => map.set(char, upperChars[index]));
  [...LOWER].forEach((char, index) => map.set(char, lowerChars[index]));
  [...DIGITS].forEach((char, index) => map.set(char, digitChars[index]));
  return map;
}

const MAPS = {
  script: makeMap(
    "𝒜ℬ𝒞𝒟ℰℱ𝒢ℋℐ𝒥𝒦ℒℳ𝒩𝒪𝒫𝒬ℛ𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵",
    "𝒶𝒷𝒸𝒹ℯ𝒻ℊ𝒽𝒾𝒿𝓀𝓁𝓂𝓃ℴ𝓅𝓆𝓇𝓈𝓉𝓊𝓋𝓌𝓍𝓎𝓏"
  ),
  boldScript: makeMap(
    "𝓐𝓑𝓒𝓓𝓔𝓕𝓖𝓗𝓘𝓙𝓚𝓛𝓜𝓝𝓞𝓟𝓠𝓡𝓢𝓣𝓤𝓥𝓦𝓧𝓨𝓩",
    "𝓪𝓫𝓬𝓭𝓮𝓯𝓰𝓱𝓲𝓳𝓴𝓵𝓶𝓷𝓸𝓹𝓺𝓻𝓼𝓽𝓾𝓿𝔀𝔁𝔂𝔃"
  ),
  fraktur: makeMap(
    "𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ",
    "𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷"
  ),
  double: makeMap(
    "𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ",
    "𝕒𝕓𝕔𝕕𝕖𝕗𝕘𝕙𝕚𝕛𝕜𝕝𝕞𝕟𝕠𝕡𝕢𝕣𝕤𝕥𝕦𝕧𝕨𝕩𝕪𝕫",
    "𝟘𝟙𝟚𝟛𝟜𝟝𝟞𝟟𝟠𝟡"
  ),
  bold: makeMap(
    "𝐀𝐁𝐂𝐃𝐄𝐅𝐆𝐇𝐈𝐉𝐊𝐋𝐌𝐍𝐎𝐏𝐐𝐑𝐒𝐓𝐔𝐕𝐖𝐗𝐘𝐙",
    "𝐚𝐛𝐜𝐝𝐞𝐟𝐠𝐡𝐢𝐣𝐤𝐥𝐦𝐧𝐨𝐩𝐪𝐫𝐬𝐭𝐮𝐯𝐰𝐱𝐲𝐳",
    "𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗"
  ),
  italic: makeMap(
    "𝐴𝐵𝐶𝐷𝐸𝐹𝐺𝐻𝐼𝐽𝐾𝐿𝑀𝑁𝑂𝑃𝑄𝑅𝑆𝑇𝑈𝑉𝑊𝑋𝑌𝑍",
    "𝑎𝑏𝑐𝑑𝑒𝑓𝑔ℎ𝑖𝑗𝑘𝑙𝑚𝑛𝑜𝑝𝑞𝑟𝑠𝑡𝑢𝑣𝑤𝑥𝑦𝑧"
  ),
  sans: makeMap(
    "𝖠𝖡𝖢𝖣𝖤𝖥𝖦𝖧𝖨𝖩𝖪𝖫𝖬𝖭𝖮𝖯𝖰𝖱𝖲𝖳𝖴𝖵𝖶𝖷𝖸𝖹",
    "𝖺𝖻𝖼𝖽𝖾𝖿𝗀𝗁𝗂𝗃𝗄𝗅𝗆𝗇𝗈𝗉𝗊𝗋𝗌𝗍𝗎𝗏𝗐𝗑𝗒𝗓",
    "𝟢𝟣𝟤𝟥𝟦𝟧𝟨𝟩𝟪𝟫"
  ),
  sansBold: makeMap(
    "𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭",
    "𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇",
    "𝟬𝟭𝟮𝟯𝟰𝟱𝟲𝟳𝟴𝟵"
  ),
  mono: makeMap(
    "𝙰𝙱𝙲𝙳𝙴𝙵𝙶𝙷𝙸𝙹𝙺𝙻𝙼𝙽𝙾𝙿𝚀𝚁𝚂𝚃𝚄𝚅𝚆𝚇𝚈𝚉",
    "𝚊𝚋𝚌𝚍𝚎𝚏𝚐𝚑𝚒𝚓𝚔𝚕𝚖𝚗𝚘𝚙𝚚𝚛𝚜𝚝𝚞𝚟𝚠𝚡𝚢𝚣",
    "𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿"
  ),
  circled: makeMap(
    "ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ",
    "ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ",
    "⓪①②③④⑤⑥⑦⑧⑨"
  ),
  fullwidth: makeMap(
    "ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ",
    "ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ",
    "０１２３４５６７８９"
  ),
  boldItalic: makeMap(
    "𝑨𝑩𝑪𝑫𝑬𝑭𝑮𝑯𝑰𝑱𝑲𝑳𝑴𝑵𝑶𝑷𝑸𝑹𝑺𝑻𝑼𝑽𝑾𝑿𝒀𝒁",
    "𝒂𝒃𝒄𝒅𝒆𝒇𝒈𝒉𝒊𝒋𝒌𝒍𝒎𝒏𝒐𝒑𝒒𝒓𝒔𝒕𝒖𝒗𝒘𝒙𝒚𝒛"
  ),
  sansItalic: makeMap(
    "𝘈𝘉𝘊𝘋𝘌𝘍𝘎𝘏𝘐𝘑𝘒𝘓𝘔𝘕𝘖𝘗𝘘𝘙𝘚𝘛𝘜𝘝𝘞𝘟𝘠𝘡",
    "𝘢𝘣𝘤𝘥𝘦𝘧𝘨𝘩𝘪𝘫𝘬𝘭𝘮𝘯𝘰𝘱𝘲𝘳𝘴𝘵𝘶𝘷𝘸𝘹𝘺𝘻"
  ),
  sansBoldItalic: makeMap(
    "𝘼𝘽𝘾𝘿𝙀𝙁𝙂𝙃𝙄𝙅𝙆𝙇𝙈𝙉𝙊𝙋𝙌𝙍𝙎𝙏𝙐𝙑𝙒𝙓𝙔𝙕",
    "𝙖𝙗𝙘𝙙𝙚𝙛𝙜𝙝𝙞𝙟𝙠𝙡𝙢𝙣𝙤𝙥𝙦𝙧𝙨𝙩𝙪𝙫𝙬𝙭𝙮𝙯"
  ),
  boldFraktur: makeMap(
    "𝕬𝕭𝕮𝕯𝕰𝕱𝕲𝕳𝕴𝕵𝕶𝕷𝕸𝕹𝕺𝕻𝕼𝕽𝕾𝕿𝖀𝖁𝖂𝖃𝖄𝖅",
    "𝖆𝖇𝖈𝖉𝖊𝖋𝖌𝖍𝖎𝖏𝖐𝖑𝖒𝖓𝖔𝖕𝖖𝖗𝖘𝖙𝖚𝖛𝖜𝖝𝖞𝖟"
  ),
  smallCaps: makeMap(
    "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘꞯʀꜱᴛᴜᴠᴡxʏᴢ",
    "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘꞯʀꜱᴛᴜᴠᴡxʏᴢ"
  ),
  parenthesized: makeMap(
    "🄐🄑🄒🄓🄔🄕🄖🄗🄘🄙🄚🄛🄜🄝🄞🄟🄠🄡🄢🄣🄤🄥🄦🄧🄨🄩",
    "⒜⒝⒞⒟⒠⒡⒢⒣⒤⒥⒦⒧⒨⒩⒪⒫⒬⒭⒮⒯⒰⒱⒲⒳⒴⒵"
  )
};

export const STYLE_CATEGORIES = [
  { id: "featured", label: "精选" },
  { id: "universal", label: "中英装饰" },
  { id: "gentle", label: "轻盈" },
  { id: "sweet", label: "可爱" },
  { id: "classic", label: "典雅" },
  { id: "cool", label: "个性" },
  { id: "latin", label: "英文变形" },
  { id: "original", label: "原创" },
  { id: "all", label: "全部" }
];

export const STYLES = [
  { id: "plain", name: "留白", category: "gentle", hint: "中英文通用", compatibility: "high", featured: true },
  { id: "spark", name: "微光", category: "gentle", prefix: "✦ ", suffix: " ✦", hint: "中英文通用", compatibility: "high", featured: true },
  { id: "flowerWindow", name: "花窗", category: "gentle", prefix: "❀ ", suffix: " ❀", hint: "原创 · 中英文通用", compatibility: "high", featured: true, original: true },
  { id: "corner", name: "书页", category: "classic", prefix: "「 ", suffix: " 」", hint: "中英文通用", compatibility: "high", featured: true },
  { id: "poemQuote", name: "诗行", category: "classic", prefix: "〝 ", suffix: " 〞", hint: "原创 · 中英文通用", compatibility: "high", featured: true, original: true },
  { id: "jadeSeal", name: "玉印", category: "classic", prefix: "〖 ", suffix: " 〗", hint: "原创 · 中文题签感", compatibility: "high", featured: true, original: true },
  { id: "sealTiles", name: "方格印", category: "classic", graphemePrefix: "〔", graphemeSuffix: "〕", hint: "原创 · 逐字入印", compatibility: "high", featured: true, original: true },
  { id: "doubleCorner", name: "藏书票", category: "classic", prefix: "『 ", suffix: " 』", hint: "中英文通用", compatibility: "high" },
  { id: "bow", name: "蝴蝶结", category: "sweet", prefix: "୨୧ ", suffix: " ୨୧", hint: "中英文通用", compatibility: "medium" },
  { id: "pearl", name: "珍珠", category: "sweet", prefix: "₊˚⊹♡ ", suffix: " ♡⊹˚₊", hint: "中英文通用", compatibility: "high", featured: true },
  { id: "moon", name: "月相", category: "gentle", prefix: "☾ ", suffix: " ☽", hint: "中英文通用", compatibility: "high" },
  { id: "starfield", name: "星屿", category: "gentle", prefix: "⋆˙⟡ ", suffix: " ⟡˙⋆", hint: "中英文通用", compatibility: "high" },
  { id: "royal", name: "鎏金", category: "classic", prefix: "꧁ ", suffix: " ꧂", hint: "中英文通用", compatibility: "medium" },
  { id: "wing", name: "羽翼", category: "cool", prefix: "𓆩 ", suffix: " 𓆪", hint: "部分设备可能缺字", compatibility: "low" },
  { id: "dotline", name: "点点", category: "sweet", joiner: " · ", hint: "逐字点缀", compatibility: "high", featured: true },
  { id: "spaced", name: "呼吸感", category: "gentle", joiner: "　", hint: "逐字留白", compatibility: "high" },
  { id: "inkRule", name: "墨线", category: "classic", prefix: "── · ", suffix: " · ──", hint: "原创 · 适合短句", compatibility: "high", original: true },
  { id: "bambooSlip", name: "竹简", category: "classic", prefix: "┊ ", suffix: " ┊", hint: "原创 · 清简中式", compatibility: "high", original: true },
  { id: "sunLetter", name: "晴光", category: "gentle", prefix: "☀︎ ", suffix: " ☀︎", hint: "原创 · 外观因设备略异", compatibility: "medium", original: true },
  { id: "cloudLetter", name: "云朵信", category: "gentle", prefix: "☁︎ ", suffix: " ☁︎", hint: "原创 · 外观因设备略异", compatibility: "medium", original: true },
  { id: "lanternGlow", name: "灯影", category: "sweet", prefix: "🏮 ", suffix: " 🏮", hint: "原创 · 节日短句", compatibility: "medium", original: true },
  { id: "paperPlane", name: "远方来信", category: "cool", prefix: "➶ ", suffix: " ➶", hint: "原创 · 中英文通用", compatibility: "high", original: true },
  { id: "diamondTrail", name: "玉石路", category: "classic", joiner: " ◇ ", hint: "原创 · 逐字玉珠", compatibility: "high", original: true },
  { id: "starStitch", name: "星缝", category: "gentle", joiner: " ✧ ", hint: "原创 · 逐字星点", compatibility: "high", original: true },
  { id: "petalTrail", name: "花径", category: "sweet", joiner: " ❀ ", hint: "原创 · 逐字花瓣", compatibility: "high", original: true },
  { id: "alternatingGlow", name: "星点节拍", category: "gentle", prefix: "✦ ", suffix: " ✦", joinerCycle: [" · ", " ✧ "], hint: "原创 · 星点交替", compatibility: "high", original: true },
  { id: "scrollFrame", name: "小卷轴", category: "classic", blockPrefix: "╭─ ✦ ─╮\n", blockSuffix: "\n╰─ ✦ ─╯", hint: "原创 · 多行整体成框", compatibility: "high", original: true },
  { id: "script", name: "手写体", category: "latin", map: "script", hint: "英文花体，数字保留", compatibility: "medium", featured: true },
  { id: "boldScript", name: "浓墨手写", category: "latin", map: "boldScript", hint: "英文花体，数字保留", compatibility: "medium" },
  { id: "italic", name: "杂志斜体", category: "latin", map: "italic", hint: "英文花体，数字保留", compatibility: "medium" },
  { id: "double", name: "双线体", category: "latin", map: "double", hint: "英数专属", compatibility: "medium" },
  { id: "bold", name: "醒目粗体", category: "cool", map: "bold", hint: "英数专属", compatibility: "medium", featured: true },
  { id: "sansBold", name: "海报黑体", category: "cool", map: "sansBold", hint: "英数专属", compatibility: "medium" },
  { id: "fraktur", name: "古典哥特", category: "classic", map: "fraktur", hint: "英文花体，数字保留", compatibility: "medium" },
  { id: "mono", name: "打字机", category: "cool", map: "mono", hint: "英数专属", compatibility: "medium" },
  { id: "circled", name: "泡泡字", category: "sweet", map: "circled", hint: "英数专属", compatibility: "medium" },
  { id: "fullwidth", name: "全角海报", category: "cool", map: "fullwidth", hint: "英数专属", compatibility: "high", featured: true },
  { id: "sans", name: "极简无衬线", category: "latin", map: "sans", hint: "英数专属", compatibility: "medium" },
  { id: "boldItalic", name: "主编粗斜", category: "latin", map: "boldItalic", hint: "英文粗斜体，数字保留", compatibility: "medium" },
  { id: "sansItalic", name: "轻快斜黑", category: "latin", map: "sansItalic", hint: "英文斜体，数字保留", compatibility: "medium" },
  { id: "sansBoldItalic", name: "运动黑斜", category: "cool", map: "sansBoldItalic", hint: "英文粗黑斜体，数字保留", compatibility: "medium" },
  { id: "boldFraktur", name: "暗黑哥特", category: "classic", map: "boldFraktur", hint: "英文哥特粗体，数字保留", compatibility: "medium" },
  { id: "smallCaps", name: "袖珍大写", category: "latin", map: "smallCaps", hint: "英文小型大写，数字保留", compatibility: "medium" },
  { id: "parenthesized", name: "括号印章", category: "classic", map: "parenthesized", hint: "英文字母括号体", compatibility: "medium" },
  { id: "starlitScript", name: "星尘签名", category: "sweet", map: "script", prefix: "⋆｡°✩ ", suffix: " ✩°｡⋆", hint: "原创 · 英文手写星光", compatibility: "medium", original: true },
  { id: "doubleOrbit", name: "星轨双线", category: "gentle", map: "double", prefix: "⋆ ", suffix: " ⋆", hint: "原创 · 英数双线星轨", compatibility: "medium", original: true },
  { id: "boldPoster", name: "海报标题", category: "cool", map: "sansBold", prefix: "【", suffix: "】", hint: "原创 · 醒目英文标题", compatibility: "medium", original: true },
  { id: "futureLabel", name: "未来标签", category: "cool", map: "mono", prefix: "⌜ ", suffix: " ⌟", hint: "原创 · 英数打字机", compatibility: "high", original: true },
  { id: "fullwidthAir", name: "空气海报", category: "cool", map: "fullwidth", joiner: " ", hint: "原创 · 英数字距拉开", compatibility: "high", original: true },
  { id: "italicQuote", name: "杂志引语", category: "classic", map: "italic", prefix: "“", suffix: "”", hint: "原创 · 英文杂志感", compatibility: "medium", original: true }
];

export function segmentGraphemes(value) {
  if (typeof Intl !== "undefined" && Intl.Segmenter) {
    const segmenter = new Intl.Segmenter("zh-Hans", { granularity: "grapheme" });
    return [...segmenter.segment(value)].map((item) => item.segment);
  }
  return [value];
}

const PROTECTED_SPAN =
  /(?:https?:\/\/|www\.)[^\s<>"'，。！？、；：）】》」』]+|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}|@[\p{L}\p{N}_.-]+|#[\p{L}\p{N}_-]+#?/giu;

function transformPlainSegments(text, transform) {
  let result = "";
  let cursor = 0;
  for (const match of text.matchAll(PROTECTED_SPAN)) {
    const index = match.index ?? 0;
    result += transform(text.slice(cursor, index));
    result += match[0];
    cursor = index + match[0].length;
  }
  return result + transform(text.slice(cursor));
}

function applyMap(text, mapName) {
  const map = MAPS[mapName];
  if (!map) return text;
  return transformPlainSegments(text, (part) =>
    Array.from(part, (char) => map.get(char) ?? char).join("")
  );
}

function applyJoiners(text, joiners) {
  const joinable = /[\p{L}\p{N}\p{Extended_Pictographic}]/u;
  return transformPlainSegments(text, (plainText) =>
    plainText
      .split("\n")
      .map((line) =>
        line
          .split(/(\s+)/u)
          .map((part) => {
            if (/^\s+$/u.test(part)) return part;
            let joinIndex = 0;
            const segments = segmentGraphemes(part);
            return segments
              .map((segment, index) => {
                const next = segments[index + 1];
                if (!next || !joinable.test(segment) || !joinable.test(next)) return segment;
                const joiner = joiners[joinIndex % joiners.length];
                joinIndex += 1;
                return segment + joiner;
              })
              .join("");
          })
          .join("")
      )
      .join("\n")
  );
}

function applyGraphemeWrapper(text, prefix, suffix) {
  const wrappable = /[\p{L}\p{N}\p{Extended_Pictographic}]/u;
  return transformPlainSegments(text, (plainText) =>
    plainText
      .split("\n")
      .map((line) =>
        line
          .split(/(\s+)/u)
          .map((part) => {
            if (/^\s+$/u.test(part)) return part;
            const segments = segmentGraphemes(part);
            return segments
              .map((segment) => (wrappable.test(segment) ? `${prefix}${segment}${suffix}` : segment))
              .join("");
          })
          .join("")
      )
      .join("\n")
  );
}

export function getStyle(styleId) {
  return STYLES.find((style) => style.id === styleId) ?? STYLES[0];
}

export function stylizeText(text, styleId) {
  const source = String(text ?? "").replace(/\r\n?/g, "\n");
  const style = getStyle(styleId);
  if (!source) return "";

  let result = style.map ? applyMap(source, style.map) : source;
  if (style.joiner) result = applyJoiners(result, [style.joiner]);
  if (style.joinerCycle?.length) result = applyJoiners(result, style.joinerCycle);
  if (style.graphemePrefix || style.graphemeSuffix) {
    result = applyGraphemeWrapper(result, style.graphemePrefix ?? "", style.graphemeSuffix ?? "");
  }
  if (style.prefix || style.suffix) {
    result = result
      .split("\n")
      .map((line) => (line ? `${style.prefix ?? ""}${line}${style.suffix ?? ""}` : ""))
      .join("\n");
  }
  if (style.blockPrefix || style.blockSuffix) {
    result = `${style.blockPrefix ?? ""}${result}${style.blockSuffix ?? ""}`;
  }
  return result;
}

export function stylesForCategory(categoryId) {
  if (!categoryId || categoryId === "all") return STYLES;
  if (categoryId === "featured") return STYLES.filter((style) => style.featured);
  if (categoryId === "universal") return STYLES.filter((style) => !style.map);
  if (categoryId === "latin") return STYLES.filter((style) => Boolean(style.map));
  if (categoryId === "original") return STYLES.filter((style) => style.original);
  return STYLES.filter((style) => style.category === categoryId);
}

