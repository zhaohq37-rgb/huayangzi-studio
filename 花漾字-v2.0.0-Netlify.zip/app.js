import { STYLE_CATEGORIES, getStyle, stylizeText, stylesForCategory } from "./transformer.js?v=2.0.0";

const STORAGE_KEY = "huayangzi:workspace:v1";
const MEDIA_DB_NAME = "huayangzi-media-v1";
const MEDIA_STORE_NAME = "images";
const MAX_IMAGE_BYTES = 20 * 1024 * 1024;
const MAX_IMAGE_EDGE = 2560;
const DEFAULT_ART_ELEMENTS = ["date", "seal", "caption"];
const ART_ELEMENT_IDS = ["date", "seal", "caption", "sparkles", "botanical", "frame"];
const ART_ELEMENT_NAMES = {
  date: "日期印记",
  seal: "花字印章",
  caption: "角落短句",
  sparkles: "星芒",
  botanical: "花枝",
  frame: "艺术画框"
};
const DEFAULT_TEXT = "把普通日子，写成闪闪发光的纪念\nHappy day ✦";
const SAMPLE_TEXTS = [
  "今日份的小确幸，正在派送中\nGood things take time",
  "生活明朗，万物可爱\nHave a lovely day ♡",
  "风有约，花不误\n年年岁岁不相负",
  "慢慢来，会比较快\nStay soft, stay strong",
  "把今天过成喜欢的样子\nOctober notes ✦",
  "允许一切发生，也允许自己闪闪发光",
  "今日无事，唯有开心\nLucky me 2026"
];

const THEMES = [
  {
    id: "vermillion",
    name: "朱砂小笺",
    glyph: "笺",
    background: ["#f5eadb", "#ead9c7"],
    foreground: "#7e2d25",
    accent: "#bd4b39",
    pattern: "frame"
  },
  {
    id: "jade",
    name: "青玉留白",
    glyph: "青",
    background: ["#e8f0e9", "#dbe7df"],
    foreground: "#245949",
    accent: "#5f8b78",
    pattern: "rings"
  },
  {
    id: "cream",
    name: "奶油泡泡",
    glyph: "甜",
    background: ["#fff1d9", "#f5d8d2"],
    foreground: "#62413b",
    accent: "#d78379",
    pattern: "bubbles"
  },
  {
    id: "midnight",
    name: "暗夜星河",
    glyph: "夜",
    background: ["#15182a", "#29233f"],
    foreground: "#faf2df",
    accent: "#c7a6ff",
    pattern: "stars"
  },
  {
    id: "ink",
    name: "水墨呼吸",
    glyph: "墨",
    background: ["#eeeae2", "#dcdcd6"],
    foreground: "#292826",
    accent: "#6a6964",
    pattern: "ink"
  },
  {
    id: "plum",
    name: "梅子来信",
    glyph: "梅",
    background: ["#593143", "#3f2332"],
    foreground: "#faeae6",
    accent: "#dda5a8",
    pattern: "plum"
  }
];

const FONT_OPTIONS = {
  song: {
    name: "雅宋",
    stack: '"Songti SC","STSong","SimSun","Noto Serif CJK SC",serif',
    weight: "600"
  },
  kai: {
    name: "手写",
    stack: '"Kaiti SC","STKaiti","KaiTi","楷体",serif',
    weight: "500"
  },
  modern: {
    name: "现代",
    stack: '-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif',
    weight: "650"
  },
  rounded: {
    name: "圆体",
    stack: '"Yuanti SC","YouYuan","PingFang SC","Microsoft YaHei",sans-serif',
    weight: "700"
  }
};

const RATIOS = {
  square: { name: "1:1", width: 1080, height: 1080 },
  portrait: { name: "4:5", width: 1080, height: 1350 },
  story: { name: "9:16", width: 1080, height: 1920 }
};

const INSTALL_STEPS = {
  ios: [
    "用 Safari 打开本页；如果在微信里，请先点右上角并选择“在 Safari 中打开”。",
    "点击 Safari 底部的“分享”按钮。",
    "向下滑动，选择“添加到主屏幕”，再点右上角的“添加”。"
  ],
  android: [
    "用 Chrome 或 Edge 打开本页；如果在微信里，请先选择“在浏览器中打开”。",
    "点击浏览器菜单中的“安装应用”或“添加到主屏幕”。",
    "确认安装后，花漾字会出现在手机桌面，并可离线打开。"
  ],
  windows: [
    "使用 Microsoft Edge 或 Chrome 打开本页。",
    "点击地址栏右侧的安装图标；如果没有看到，请打开浏览器菜单。",
    "选择“安装花漾字”并确认，之后点桌面图标就能打开。"
  ]
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function loadWorkspace() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
  } catch {
    return {};
  }
}

function todayInputValue() {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function normalizeBackground(value) {
  if (value?.type === "image" && typeof value.imageId === "string" && value.imageId) {
    return {
      type: "image",
      imageId: value.imageId,
      imageName: typeof value.imageName === "string" ? value.imageName.slice(0, 120) : "自选图片"
    };
  }
  return { type: "theme", imageId: null, imageName: "" };
}

function normalizeArtElements(value) {
  const source = Array.isArray(value) ? value : DEFAULT_ART_ELEMENTS;
  return [...new Set(source.filter((id) => ART_ELEMENT_IDS.includes(id)))];
}

function normalizeImageOpacity(value) {
  return Number.isFinite(value) ? Math.min(1, Math.max(0, value)) : 0.72;
}

function sanitizeShortText(value, fallback, maxLength) {
  const text = typeof value === "string" ? value.trim() : "";
  return textSegments(text || fallback).slice(0, maxLength).join("");
}

const stored = loadWorkspace();
const state = {
  text: typeof stored.text === "string" ? stored.text : DEFAULT_TEXT,
  copyText: typeof stored.copyText === "string" ? stored.copyText : DEFAULT_TEXT,
  theme: THEMES.some((theme) => theme.id === stored.theme) ? stored.theme : "vermillion",
  font: FONT_OPTIONS[stored.font] ? stored.font : "song",
  ratio: RATIOS[stored.ratio] ? stored.ratio : "square",
  fontSize: Number.isFinite(stored.fontSize) ? stored.fontSize : 72,
  align: ["left", "center", "right"].includes(stored.align) ? stored.align : "center",
  background: normalizeBackground(stored.background),
  imageFit: ["cover", "contain"].includes(stored.imageFit) ? stored.imageFit : "cover",
  imageOpacity: normalizeImageOpacity(stored.imageOpacity),
  artElements: normalizeArtElements(stored.artElements),
  designDate: /^\d{4}-\d{2}-\d{2}$/.test(stored.designDate || "") ? stored.designDate : todayInputValue(),
  sealText: sanitizeShortText(stored.sealText, "花", 2),
  captionText: sanitizeShortText(stored.captionText, "愿你自在生长", 24),
  activeCategory: "featured",
  favorites: Array.isArray(stored.favorites) ? stored.favorites.filter((id) => getStyle(id).id === id) : [],
  works: Array.isArray(stored.works) ? stored.works.slice(0, 18) : [],
  history: Array.isArray(stored.history) ? stored.history.slice(0, 20) : [],
  currentView: "card"
};

let saveTimer = 0;
let toastTimer = 0;
let exportObjectUrl = "";
let currentExportBlob = null;
let deferredInstallPrompt = null;
let isComposing = false;
let canvasOverflow = false;
let activeBackgroundImage = null;
let activeBackgroundUrl = "";
let activeBackgroundBlob = null;
let backgroundLoadToken = 0;
let activeUploadToken = 0;
let backgroundReadyPromise = Promise.resolve();

const els = {
  mainInput: $("#mainInput"),
  copyInput: $("#copyInput"),
  charCount: $("#charCount"),
  copyCharCount: $("#copyCharCount"),
  saveState: $("#saveState"),
  themeGrid: $("#themeGrid"),
  fontOptions: $("#fontOptions"),
  ratioOptions: $("#ratioOptions"),
  alignOptions: $("#alignOptions"),
  fontSize: $("#fontSize"),
  fontSizeValue: $("#fontSizeValue"),
  canvas: $("#artCanvas"),
  canvasDescription: $("#canvasDescription"),
  overflowNotice: $("#overflowNotice"),
  categoryFilters: $("#categoryFilters"),
  styleGrid: $("#styleGrid"),
  styleResultStatus: $("#styleResultStatus"),
  backgroundImageInput: $("#backgroundImageInput"),
  backgroundImageThumbnail: $("#backgroundImageThumbnail"),
  backgroundImagePlaceholder: $("#backgroundImagePlaceholder"),
  removeBackgroundImage: $("#removeBackgroundImage"),
  backgroundImageStatus: $("#backgroundImageStatus"),
  imageFitOptions: $("#backgroundFitOptions"),
  imageOpacity: $("#backgroundOpacity"),
  imageOpacityValue: $("#backgroundOpacityValue"),
  artElementOptions: $("#artElementOptions"),
  artDate: $("#artDateInput"),
  sealText: $("#sealTextInput"),
  captionText: $("#captionTextInput"),
  worksGrid: $("#worksGrid"),
  favoritesList: $("#favoritesList"),
  worksCount: $("#worksCount"),
  favoritesCount: $("#favoritesCount"),
  mobileActionBar: $("#mobileActionBar"),
  exportDialog: $("#exportDialog"),
  exportPreview: $("#exportPreview"),
  installDialog: $("#installDialog"),
  installSteps: $("#installSteps"),
  toast: $("#toast")
};

function persistWorkspace(immediate = false) {
  window.clearTimeout(saveTimer);
  els.saveState.textContent = "保存中…";
  const commit = () => {
    try {
      const payload = {
        schemaVersion: 2,
        text: state.text,
        copyText: state.copyText,
        theme: state.theme,
        font: state.font,
        ratio: state.ratio,
        fontSize: state.fontSize,
        align: state.align,
        background: state.background,
        imageFit: state.imageFit,
        imageOpacity: state.imageOpacity,
        artElements: state.artElements,
        designDate: state.designDate,
        sealText: state.sealText,
        captionText: state.captionText,
        favorites: state.favorites,
        works: state.works,
        history: state.history
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
      els.saveState.textContent = "已保存在本机";
    } catch {
      els.saveState.textContent = "保存失败";
      showToast("本机存储空间不足，请先清理部分记录");
    }
  };
  if (immediate) commit();
  else saveTimer = window.setTimeout(commit, 360);
}

function showToast(message) {
  window.clearTimeout(toastTimer);
  els.toast.textContent = message;
  els.toast.classList.add("is-visible");
  toastTimer = window.setTimeout(() => els.toast.classList.remove("is-visible"), 2600);
}

function hideToast() {
  window.clearTimeout(toastTimer);
  els.toast.classList.remove("is-visible");
}

let mediaDbPromise = null;

function openMediaDb() {
  if (!window.indexedDB) return Promise.reject(new Error("IndexedDB unavailable"));
  if (mediaDbPromise) return mediaDbPromise;
  mediaDbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(MEDIA_DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(MEDIA_STORE_NAME)) {
        db.createObjectStore(MEDIA_STORE_NAME, { keyPath: "id" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Unable to open image storage"));
  });
  return mediaDbPromise;
}

async function putMediaBlob(id, blob, name) {
  const db = await openMediaDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(MEDIA_STORE_NAME, "readwrite");
    transaction.objectStore(MEDIA_STORE_NAME).put({ id, blob, name, updatedAt: Date.now() });
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error || new Error("Unable to save image"));
    transaction.onabort = () => reject(transaction.error || new Error("Unable to save image"));
  });
}

async function getMediaRecord(id) {
  if (!id) return null;
  const db = await openMediaDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(MEDIA_STORE_NAME, "readonly");
    const request = transaction.objectStore(MEDIA_STORE_NAME).get(id);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error || new Error("Unable to read image"));
  });
}

async function pruneUnusedMedia() {
  try {
    const db = await openMediaDb();
    await new Promise((resolve, reject) => {
      const transaction = db.transaction(MEDIA_STORE_NAME, "readwrite");
      const request = transaction.objectStore(MEDIA_STORE_NAME).openCursor();
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor) return;
        const keep = new Set(
          [state.background, ...state.works.map((work) => work.background)]
            .filter((background) => background?.type === "image" && background.imageId)
            .map((background) => background.imageId)
        );
        const age = Date.now() - Number(cursor.value?.updatedAt || 0);
        if (!keep.has(cursor.key) && age > 60_000) cursor.delete();
        cursor.continue();
      };
      request.onerror = () => reject(request.error || new Error("Unable to clean image storage"));
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error || new Error("Unable to clean image storage"));
    });
  } catch {
    // Image cleanup is best-effort and must never block editing.
  }
}

function loadImageElement(blob) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    const image = new Image();
    image.onload = () => resolve({ image, url });
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Image decode failed"));
    };
    image.src = url;
  });
}

async function compressBackgroundImage(file) {
  const { image, url } = await loadImageElement(file);
  try {
    const naturalWidth = image.naturalWidth || image.width;
    const naturalHeight = image.naturalHeight || image.height;
    if (!naturalWidth || !naturalHeight) throw new Error("Image has no dimensions");
    const scale = Math.min(1, MAX_IMAGE_EDGE / Math.max(naturalWidth, naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(naturalHeight * scale));
    const ctx = canvas.getContext("2d", { alpha: true });
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    let blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/webp", 0.9));
    if (!blob) blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
    if (!blob) throw new Error("Image compression failed");
    return blob;
  } finally {
    URL.revokeObjectURL(url);
  }
}

function clearActiveBackgroundImage() {
  backgroundLoadToken += 1;
  activeUploadToken = 0;
  if (activeBackgroundUrl) URL.revokeObjectURL(activeBackgroundUrl);
  activeBackgroundImage = null;
  activeBackgroundUrl = "";
  activeBackgroundBlob = null;
  backgroundReadyPromise = Promise.resolve();
  if (els.backgroundImageInput) {
    els.backgroundImageInput.disabled = false;
    els.backgroundImageInput.value = "";
  }
}

function setActiveBackground(blob, loaded, token) {
  if (token !== backgroundLoadToken) {
    URL.revokeObjectURL(loaded.url);
    return false;
  }
  if (activeBackgroundUrl) URL.revokeObjectURL(activeBackgroundUrl);
  activeBackgroundImage = loaded.image;
  activeBackgroundUrl = loaded.url;
  activeBackgroundBlob = blob;
  return true;
}

function activateBackgroundImage(imageId, options = {}) {
  activeUploadToken = 0;
  const token = ++backgroundLoadToken;
  backgroundReadyPromise = (async () => {
    try {
      const record = await getMediaRecord(imageId);
      if (!record?.blob) throw new Error("Missing image");
      const loaded = await loadImageElement(record.blob);
      if (!setActiveBackground(record.blob, loaded, token)) return false;
      renderCanvas();
      syncDiyControls();
      return true;
    } catch {
      if (token !== backgroundLoadToken) return false;
      if (activeBackgroundUrl) URL.revokeObjectURL(activeBackgroundUrl);
      activeBackgroundImage = null;
      activeBackgroundUrl = "";
      activeBackgroundBlob = null;
      activeUploadToken = 0;
      state.background = { type: "theme", imageId: null, imageName: "" };
      syncDiyControls();
      renderCanvas();
      persistWorkspace(true);
      if (!options.silent) showToast("这张背景图已不存在，请重新选择");
      return false;
    }
  })();
  return backgroundReadyPromise;
}

function setTransientBackground(blob, image, url, name, token = ++backgroundLoadToken) {
  if (!setActiveBackground(blob, { image, url }, token)) return false;
  state.background = { type: "image", imageId: null, imageName: name };
  return true;
}

function graphemeCount(value) {
  if (Intl.Segmenter) {
    return [...new Intl.Segmenter("zh-Hans", { granularity: "grapheme" }).segment(value)].length;
  }
  return Array.from(value).length;
}

function syncCounts() {
  els.charCount.textContent = graphemeCount(state.text) + " / 180";
  els.copyCharCount.textContent = graphemeCount(state.copyText) + " / 180";
}

function currentTheme() {
  return THEMES.find((theme) => theme.id === state.theme) || THEMES[0];
}

function hexToRgba(hex, alpha) {
  const value = hex.replace("#", "");
  const expanded = value.length === 3 ? value.split("").map((char) => char + char).join("") : value;
  const number = Number.parseInt(expanded, 16);
  const red = (number >> 16) & 255;
  const green = (number >> 8) & 255;
  const blue = number & 255;
  return "rgba(" + red + "," + green + "," + blue + "," + alpha + ")";
}

function drawRoundedRect(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + width, y, x + width, y + height, r);
  ctx.arcTo(x + width, y + height, x, y + height, r);
  ctx.arcTo(x, y + height, x, y, r);
  ctx.arcTo(x, y, x + width, y, r);
  ctx.closePath();
}

function drawBackground(ctx, width, height, theme, includePattern = true) {
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, theme.background[0]);
  gradient.addColorStop(1, theme.background[1]);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);
  if (!includePattern) return;

  ctx.save();
  ctx.strokeStyle = hexToRgba(theme.accent, 0.3);
  ctx.fillStyle = hexToRgba(theme.accent, 0.13);
  ctx.lineWidth = Math.max(2, width / 500);

  if (theme.pattern === "frame") {
    const inset = width * 0.055;
    ctx.strokeRect(inset, inset, width - inset * 2, height - inset * 2);
    ctx.strokeStyle = hexToRgba(theme.accent, 0.14);
    ctx.strokeRect(inset + 12, inset + 12, width - (inset + 12) * 2, height - (inset + 12) * 2);
    ctx.beginPath();
    ctx.arc(width - inset * 1.4, inset * 1.4, width * 0.075, 0, Math.PI * 2);
    ctx.stroke();
  }

  if (theme.pattern === "rings") {
    [0.14, 0.22, 0.31].forEach((factor) => {
      ctx.beginPath();
      ctx.arc(width * 0.9, height * 0.1, width * factor, 0, Math.PI * 2);
      ctx.stroke();
    });
    ctx.beginPath();
    ctx.arc(width * 0.08, height * 0.89, width * 0.16, 0, Math.PI * 2);
    ctx.stroke();
  }

  if (theme.pattern === "bubbles") {
    [
      [0.12, 0.17, 0.075],
      [0.84, 0.13, 0.11],
      [0.89, 0.82, 0.16],
      [0.11, 0.88, 0.04]
    ].forEach(([x, y, radius]) => {
      ctx.beginPath();
      ctx.arc(width * x, height * y, width * radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    });
  }

  if (theme.pattern === "stars") {
    const stars = [
      [0.12, 0.13, 4],
      [0.22, 0.27, 2],
      [0.81, 0.16, 3],
      [0.9, 0.36, 2],
      [0.12, 0.72, 2],
      [0.78, 0.79, 4],
      [0.63, 0.91, 2],
      [0.31, 0.87, 3],
      [0.55, 0.11, 2]
    ];
    ctx.fillStyle = hexToRgba(theme.accent, 0.66);
    stars.forEach(([x, y, radius]) => {
      ctx.beginPath();
      ctx.arc(width * x, height * y, radius * (width / 540), 0, Math.PI * 2);
      ctx.fill();
    });
    const glow = ctx.createRadialGradient(width * 0.75, height * 0.33, 0, width * 0.75, height * 0.33, width * 0.38);
    glow.addColorStop(0, hexToRgba(theme.accent, 0.12));
    glow.addColorStop(1, hexToRgba(theme.accent, 0));
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, width, height);
  }

  if (theme.pattern === "ink") {
    const wash = ctx.createRadialGradient(width * 0.77, height * 0.25, 0, width * 0.77, height * 0.25, width * 0.38);
    wash.addColorStop(0, "rgba(30,30,30,.12)");
    wash.addColorStop(0.45, "rgba(30,30,30,.045)");
    wash.addColorStop(1, "rgba(30,30,30,0)");
    ctx.fillStyle = wash;
    ctx.fillRect(0, 0, width, height);
    ctx.strokeStyle = "rgba(30,30,30,.13)";
    ctx.beginPath();
    ctx.moveTo(width * 0.06, height * 0.81);
    ctx.bezierCurveTo(width * 0.23, height * 0.72, width * 0.33, height * 0.94, width * 0.55, height * 0.85);
    ctx.stroke();
  }

  if (theme.pattern === "plum") {
    ctx.strokeStyle = hexToRgba(theme.accent, 0.4);
    ctx.lineWidth = width * 0.006;
    ctx.beginPath();
    ctx.moveTo(width, height * 0.15);
    ctx.bezierCurveTo(width * 0.86, height * 0.2, width * 0.86, height * 0.28, width * 0.71, height * 0.33);
    ctx.stroke();
    [
      [0.88, 0.22],
      [0.8, 0.27],
      [0.73, 0.32]
    ].forEach(([x, y]) => {
      ctx.beginPath();
      ctx.arc(width * x, height * y, width * 0.018, 0, Math.PI * 2);
      ctx.fillStyle = hexToRgba(theme.accent, 0.52);
      ctx.fill();
    });
  }
  ctx.restore();
}

function textSegments(value) {
  if (Intl.Segmenter) {
    return [...new Intl.Segmenter("zh-Hans", { granularity: "grapheme" }).segment(value)].map((part) => part.segment);
  }
  return Array.from(value);
}

function wrapCanvasText(ctx, value, maxWidth) {
  const output = [];
  const sourceLines = String(value || "").split("\n");
  sourceLines.forEach((sourceLine) => {
    if (!sourceLine) {
      output.push("");
      return;
    }
    if (ctx.measureText(sourceLine).width <= maxWidth) {
      output.push(sourceLine);
      return;
    }
    let line = "";
    textSegments(sourceLine).forEach((segment) => {
      const candidate = line + segment;
      if (line && ctx.measureText(candidate).width > maxWidth) {
        output.push(line.trimEnd());
        line = segment.trimStart();
      } else {
        line = candidate;
      }
    });
    if (line) output.push(line.trimEnd());
  });
  return output;
}

function formatCanvasDate(value = state.designDate) {
  const [year, month, day] = String(value || todayInputValue()).split("-");
  return [year, month, day].filter(Boolean).join(" · ");
}

function drawSelectedBackground(ctx, width, height, theme) {
  if (state.background.type !== "image" || !activeBackgroundImage) return;
  const imageWidth = activeBackgroundImage.naturalWidth || activeBackgroundImage.width;
  const imageHeight = activeBackgroundImage.naturalHeight || activeBackgroundImage.height;
  if (!imageWidth || !imageHeight) return;
  const scale = state.imageFit === "contain"
    ? Math.min(width / imageWidth, height / imageHeight)
    : Math.max(width / imageWidth, height / imageHeight);
  const drawWidth = imageWidth * scale;
  const drawHeight = imageHeight * scale;
  const drawX = (width - drawWidth) / 2;
  const drawY = (height - drawHeight) / 2;

  ctx.save();
  ctx.globalAlpha = state.imageOpacity;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(activeBackgroundImage, drawX, drawY, drawWidth, drawHeight);
  ctx.restore();

  ctx.save();
  ctx.fillStyle = hexToRgba(theme.background[0], 0.1 + (1 - state.imageOpacity) * 0.08);
  ctx.fillRect(0, 0, width, height);
  ctx.restore();
}

function drawFourPointStar(ctx, x, y, radius, color, alpha = 1) {
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = hexToRgba(color, alpha);
  ctx.beginPath();
  ctx.moveTo(0, -radius);
  ctx.quadraticCurveTo(radius * 0.16, -radius * 0.16, radius, 0);
  ctx.quadraticCurveTo(radius * 0.16, radius * 0.16, 0, radius);
  ctx.quadraticCurveTo(-radius * 0.16, radius * 0.16, -radius, 0);
  ctx.quadraticCurveTo(-radius * 0.16, -radius * 0.16, 0, -radius);
  ctx.fill();
  ctx.restore();
}

function drawBotanical(ctx, width, height, theme) {
  const scale = width / 1080;
  ctx.save();
  ctx.strokeStyle = hexToRgba(theme.accent, 0.66);
  ctx.fillStyle = hexToRgba(theme.accent, 0.26);
  ctx.lineWidth = Math.max(3, 4 * scale);
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(width * 0.08, height * 0.78);
  ctx.bezierCurveTo(width * 0.14, height * 0.72, width * 0.2, height * 0.7, width * 0.29, height * 0.62);
  ctx.stroke();

  [
    [0.125, 0.735, -0.85],
    [0.165, 0.71, 0.72],
    [0.205, 0.685, -0.72],
    [0.245, 0.652, 0.62]
  ].forEach(([x, y, rotation]) => {
    ctx.save();
    ctx.translate(width * x, height * y);
    ctx.rotate(rotation);
    ctx.beginPath();
    ctx.ellipse(0, 0, 24 * scale, 9 * scale, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  });

  [
    [0.112, 0.75, 17],
    [0.216, 0.675, 21],
    [0.292, 0.615, 16]
  ].forEach(([x, y, radius]) => {
    for (let petal = 0; petal < 5; petal += 1) {
      const angle = (Math.PI * 2 * petal) / 5;
      ctx.beginPath();
      ctx.arc(
        width * x + Math.cos(angle) * radius * 0.55 * scale,
        height * y + Math.sin(angle) * radius * 0.55 * scale,
        radius * 0.48 * scale,
        0,
        Math.PI * 2
      );
      ctx.fill();
    }
    ctx.beginPath();
    ctx.fillStyle = hexToRgba(theme.accent, 0.72);
    ctx.arc(width * x, height * y, radius * 0.28 * scale, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = hexToRgba(theme.accent, 0.26);
  });
  ctx.restore();
}

function drawArtElements(ctx, width, height, theme, layer) {
  const enabled = (id) => state.artElements.includes(id);
  if (layer === "background") {
    if (enabled("frame")) {
      const inset = width * 0.045;
      ctx.save();
      ctx.strokeStyle = hexToRgba(theme.accent, 0.72);
      ctx.lineWidth = Math.max(2, width * 0.003);
      drawRoundedRect(ctx, inset, inset, width - inset * 2, height - inset * 2, width * 0.015);
      ctx.stroke();
      ctx.strokeStyle = hexToRgba(theme.accent, 0.3);
      ctx.lineWidth = Math.max(1, width * 0.0015);
      drawRoundedRect(ctx, inset + width * 0.012, inset + width * 0.012, width - (inset + width * 0.012) * 2, height - (inset + width * 0.012) * 2, width * 0.01);
      ctx.stroke();
      ctx.restore();
    }
    if (enabled("botanical")) drawBotanical(ctx, width, height, theme);
    if (enabled("sparkles")) {
      drawFourPointStar(ctx, width * 0.14, height * 0.18, width * 0.022, theme.accent, 0.72);
      drawFourPointStar(ctx, width * 0.84, height * 0.22, width * 0.014, theme.accent, 0.55);
      drawFourPointStar(ctx, width * 0.79, height * 0.79, width * 0.027, theme.accent, 0.62);
      drawFourPointStar(ctx, width * 0.19, height * 0.83, width * 0.01, theme.accent, 0.48);
    }
    return;
  }

  ctx.save();
  ctx.fillStyle = hexToRgba(theme.foreground, 0.72);
  ctx.font = "500 " + Math.max(17, width * 0.018) + "px " + FONT_OPTIONS.modern.stack;
  ctx.letterSpacing = width * 0.002 + "px";
  if (enabled("date")) {
    ctx.textAlign = "left";
    ctx.fillText("DAILY LETTER  ·  " + formatCanvasDate(), width * 0.09, height * 0.09);
  }
  if (enabled("caption")) {
    ctx.textAlign = "right";
    const caption = state.captionText.trim() || "愿你自在生长";
    ctx.fillText(caption, width * 0.91, height * 0.92, width * 0.52);
  }
  ctx.restore();

  if (enabled("seal")) {
    ctx.save();
    const stampSize = width * 0.066;
    const stampX = width * 0.09;
    const stampY = height * 0.86;
    const seal = sanitizeShortText(state.sealText, "花", 2);
    ctx.fillStyle = theme.accent;
    drawRoundedRect(ctx, stampX, stampY, stampSize, stampSize, stampSize * 0.18);
    ctx.fill();
    ctx.fillStyle = theme.background[0];
    ctx.font = "600 " + stampSize * (seal.length > 1 ? 0.36 : 0.5) + "px " + FONT_OPTIONS.kai.stack;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(seal, stampX + stampSize / 2, stampY + stampSize / 2, stampSize * 0.84);
    ctx.restore();
  }
}

function drawCanvasText(ctx, width, height, theme) {
  const font = FONT_OPTIONS[state.font];
  let size = state.fontSize * (width / 1080);
  const minSize = 28 * (width / 1080);
  const maxWidth = width * 0.73;
  const value = state.text.trim() || "写下此刻";
  const contentTop = height * 0.17;
  const contentBottom = height * 0.8;
  const availableHeight = contentBottom - contentTop;
  ctx.font = font.weight + " " + size + "px " + font.stack;
  let lines = wrapCanvasText(ctx, value, maxWidth);

  const textHeight = () => size + Math.max(0, lines.length - 1) * size * 1.48;
  while (textHeight() > availableHeight && size > minSize) {
    size = Math.max(minSize, size - 2 * (width / 1080));
    ctx.font = font.weight + " " + size + "px " + font.stack;
    lines = wrapCanvasText(ctx, value, maxWidth);
  }

  const lineHeight = size * 1.48;
  const maxVisibleLines = Math.max(1, Math.floor((availableHeight - size) / lineHeight) + 1);
  const overflow = lines.length > maxVisibleLines;
  if (overflow) {
    lines = lines.slice(0, maxVisibleLines);
    let lastLine = lines.at(-1).replace(/…?$/, "") + "…";
    const segments = textSegments(lastLine);
    while (segments.length > 1 && ctx.measureText(segments.join("")).width > maxWidth) {
      segments.splice(-2, 1);
    }
    lines[lines.length - 1] = segments.join("");
  }

  const totalHeight = size + Math.max(0, lines.length - 1) * lineHeight;
  const top = contentTop + (availableHeight - totalHeight) / 2 + size / 2;
  const horizontalPadding = width * 0.135;
  const x =
    state.align === "left"
      ? horizontalPadding
      : state.align === "right"
        ? width - horizontalPadding
        : width / 2;

  ctx.save();
  ctx.fillStyle = theme.foreground;
  ctx.textAlign = state.align;
  ctx.textBaseline = "middle";
  ctx.font = font.weight + " " + size + "px " + font.stack;
  lines.forEach((line, index) => {
    ctx.fillText(line || " ", x, top + index * lineHeight, maxWidth);
  });
  ctx.restore();

  return overflow;
}

function renderCanvas() {
  const ratio = RATIOS[state.ratio];
  const theme = currentTheme();
  if (els.canvas.width !== ratio.width || els.canvas.height !== ratio.height) {
    els.canvas.width = ratio.width;
    els.canvas.height = ratio.height;
  }
  const ctx = els.canvas.getContext("2d");
  ctx.clearRect(0, 0, ratio.width, ratio.height);
  drawBackground(ctx, ratio.width, ratio.height, theme, state.background.type !== "image");
  drawSelectedBackground(ctx, ratio.width, ratio.height, theme);
  drawArtElements(ctx, ratio.width, ratio.height, theme, "background");
  canvasOverflow = drawCanvasText(ctx, ratio.width, ratio.height, theme);
  drawArtElements(ctx, ratio.width, ratio.height, theme, "foreground");
  els.overflowNotice.hidden = !canvasOverflow;
  const backgroundDescription = state.background.type === "image" && activeBackgroundImage ? "自选图片背景" : "主题背景";
  const decorationDescription = state.artElements.map((id) => ART_ELEMENT_NAMES[id]).join("、") || "无艺术元素";
  els.canvasDescription.textContent =
    `${theme.name}风格，${backgroundDescription}，${FONT_OPTIONS[state.font].name}字形，艺术元素：${decorationDescription}，内容为：${state.text || "空白"}`;
}

function renderThemeGrid() {
  els.themeGrid.replaceChildren();
  THEMES.forEach((theme) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "theme-option";
    button.dataset.theme = theme.id;
    button.setAttribute("role", "radio");
    button.setAttribute("aria-checked", String(state.theme === theme.id));
    button.style.setProperty("--theme-bg", theme.background[0]);
    button.style.setProperty("--theme-fg", theme.foreground);
    button.style.setProperty("--theme-accent", theme.accent);

    const name = document.createElement("span");
    name.className = "theme-name";
    name.textContent = theme.name;
    const glyph = document.createElement("span");
    glyph.className = "theme-glyph";
    glyph.textContent = theme.glyph;
    glyph.setAttribute("aria-hidden", "true");
    const check = document.createElement("span");
    check.className = "theme-check";
    check.textContent = "✓";
    check.setAttribute("aria-hidden", "true");
    button.append(name, glyph, check);
    els.themeGrid.append(button);
  });
}

function updateRadioGroup(root, dataName, value) {
  $$("button", root).forEach((button) => {
    const selected = button.dataset[dataName] === value;
    button.setAttribute("aria-checked", String(selected));
    button.classList.toggle("is-selected", selected);
    button.tabIndex = selected ? 0 : -1;
  });
}

function setupRovingRadio(root) {
  root.addEventListener("keydown", (event) => {
    const current = event.target.closest('button[role="radio"]');
    if (!current || !root.contains(current)) return;
    const buttons = $$('button[role="radio"]', root).filter((button) => !button.disabled);
    const index = buttons.indexOf(current);
    if (index < 0) return;
    let nextIndex = index;
    if (["ArrowRight", "ArrowDown"].includes(event.key)) nextIndex = (index + 1) % buttons.length;
    else if (["ArrowLeft", "ArrowUp"].includes(event.key)) nextIndex = (index - 1 + buttons.length) % buttons.length;
    else if (event.key === "Home") nextIndex = 0;
    else if (event.key === "End") nextIndex = buttons.length - 1;
    else return;
    event.preventDefault();
    buttons[nextIndex].focus();
    buttons[nextIndex].click();
  });
}

function syncDiyControls() {
  if (!els.backgroundImageInput) return;
  const hasImage = state.background.type === "image" && Boolean(activeBackgroundImage);
  els.removeBackgroundImage.disabled = state.background.type !== "image";
  if (hasImage) {
    els.backgroundImageStatus.textContent = state.background.imageId
      ? `已选择：${state.background.imageName || "自选图片"} · 仅保存在本机`
      : `已选择：${state.background.imageName || "自选图片"} · 本页临时使用`;
    els.backgroundImageThumbnail.src = activeBackgroundUrl;
    els.backgroundImageThumbnail.hidden = false;
    els.backgroundImagePlaceholder.hidden = true;
  } else {
    els.backgroundImageStatus.textContent = state.background.type === "image"
      ? "正在载入本机图片…"
      : "支持 JPG、PNG、WebP 与 HEIC";
    els.backgroundImageThumbnail.removeAttribute("src");
    els.backgroundImageThumbnail.hidden = true;
    els.backgroundImagePlaceholder.hidden = false;
  }

  updateRadioGroup(els.imageFitOptions, "backgroundFit", state.imageFit);
  const opacity = Math.round(state.imageOpacity * 100);
  els.imageOpacity.value = String(opacity);
  els.imageOpacityValue.value = `${opacity}%`;
  els.imageOpacityValue.textContent = `${opacity}%`;

  $$('[data-art-element]', els.artElementOptions).forEach((button) => {
    const selected = state.artElements.includes(button.dataset.artElement);
    button.setAttribute("aria-pressed", String(selected));
    button.classList.toggle("is-selected", selected);
  });
  els.artDate.value = state.designDate;
  els.sealText.value = state.sealText;
  els.captionText.value = state.captionText;
  for (const [input, element] of [
    [els.artDate, "date"],
    [els.sealText, "seal"],
    [els.captionText, "caption"]
  ]) {
    const enabled = state.artElements.includes(element);
    input.disabled = !enabled;
    input.closest("label")?.classList.toggle("is-disabled", !enabled);
  }
}

function isSupportedBackgroundFile(file) {
  const typeSupported = /^image\/(?:jpe?g|png|webp|heic|heif)$/iu.test(file.type || "");
  const extensionSupported = /\.(?:jpe?g|png|webp|heic|heif)$/iu.test(file.name || "");
  return typeSupported || (!file.type && extensionSupported);
}

async function handleBackgroundFile(file) {
  if (!file) return;
  if (!isSupportedBackgroundFile(file)) {
    showToast("请选择 JPG、PNG、WebP 或 HEIC 图片");
    return;
  }
  if (file.size > MAX_IMAGE_BYTES) {
    showToast("图片不能超过 20 MB，请先缩小后再试");
    return;
  }

  const operationToken = ++backgroundLoadToken;
  activeUploadToken = operationToken;
  els.backgroundImageStatus.textContent = "正在优化图片，请稍候…";
  els.backgroundImageInput.disabled = true;
  const operation = (async () => {
    let loaded = null;
    let activated = false;
    try {
      const blob = await compressBackgroundImage(file);
      if (operationToken !== backgroundLoadToken) return false;
      loaded = await loadImageElement(blob);
      if (operationToken !== backgroundLoadToken) return false;

      const imageId = `image-${crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`}`;
      let savedLocally = true;
      try {
        await putMediaBlob(imageId, blob, file.name);
      } catch {
        savedLocally = false;
      }
      if (operationToken !== backgroundLoadToken) {
        if (savedLocally) void pruneUnusedMedia();
        return false;
      }

      if (savedLocally) {
        activated = setActiveBackground(blob, loaded, operationToken);
        if (!activated) return false;
        state.background = { type: "image", imageId, imageName: file.name.slice(0, 120) };
      } else {
        activated = setTransientBackground(blob, loaded.image, loaded.url, file.name.slice(0, 120), operationToken);
        if (!activated) return false;
      }
      syncDiyControls();
      renderCanvas();
      persistWorkspace(true);
      void pruneUnusedMedia();
      showToast(savedLocally ? "背景图已加入，并保存在本机" : "背景图已加入；关闭页面后需要重新选择");
      return true;
    } catch {
      if (operationToken === backgroundLoadToken) {
        showToast("这张图片无法读取，请改用 JPG、PNG 或 WebP");
        syncDiyControls();
      }
      return false;
    } finally {
      if (loaded?.url && !activated) URL.revokeObjectURL(loaded.url);
      if (activeUploadToken === operationToken) {
        activeUploadToken = 0;
        els.backgroundImageInput.disabled = false;
        els.backgroundImageInput.value = "";
      }
    }
  })();
  backgroundReadyPromise = operation;
  return operation;
}

function setupDiyControls() {
  setupRovingRadio(els.imageFitOptions);
  syncDiyControls();

  els.backgroundImageInput.addEventListener("change", (event) => {
    void handleBackgroundFile(event.currentTarget.files?.[0]);
  });

  els.removeBackgroundImage.addEventListener("click", () => {
    clearActiveBackgroundImage();
    state.background = { type: "theme", imageId: null, imageName: "" };
    syncDiyControls();
    renderCanvas();
    persistWorkspace(true);
    void pruneUnusedMedia();
    showToast("已移除自选背景图");
  });

  els.imageFitOptions.addEventListener("click", (event) => {
    const button = event.target.closest("[data-background-fit]");
    if (!button) return;
    state.imageFit = button.dataset.backgroundFit;
    updateRadioGroup(els.imageFitOptions, "backgroundFit", state.imageFit);
    renderCanvas();
    persistWorkspace();
  });

  els.imageOpacity.addEventListener("input", (event) => {
    state.imageOpacity = normalizeImageOpacity(Number(event.currentTarget.value) / 100);
    const opacity = Math.round(state.imageOpacity * 100);
    els.imageOpacityValue.value = `${opacity}%`;
    els.imageOpacityValue.textContent = `${opacity}%`;
    renderCanvas();
    persistWorkspace();
  });

  els.artElementOptions.addEventListener("click", (event) => {
    const button = event.target.closest("[data-art-element]");
    if (!button) return;
    const element = button.dataset.artElement;
    if (!ART_ELEMENT_IDS.includes(element)) return;
    state.artElements = state.artElements.includes(element)
      ? state.artElements.filter((id) => id !== element)
      : [...state.artElements, element];
    syncDiyControls();
    renderCanvas();
    persistWorkspace();
  });

  els.artDate.addEventListener("change", (event) => {
    state.designDate = /^\d{4}-\d{2}-\d{2}$/.test(event.currentTarget.value)
      ? event.currentTarget.value
      : todayInputValue();
    syncDiyControls();
    renderCanvas();
    persistWorkspace();
  });

  els.sealText.addEventListener("input", (event) => {
    state.sealText = textSegments(event.currentTarget.value).slice(0, 2).join("");
    renderCanvas();
    persistWorkspace();
  });

  els.captionText.addEventListener("input", (event) => {
    state.captionText = textSegments(event.currentTarget.value).slice(0, 24).join("");
    renderCanvas();
    persistWorkspace();
  });
}

function setCardText(value) {
  const previous = state.text;
  state.text = value;
  let copyChanged = false;
  if (state.copyText === previous) {
    state.copyText = value;
    els.copyInput.value = value;
    copyChanged = true;
  }
  syncCounts();
  renderCanvas();
  if (copyChanged) updateStyleOutputs();
  persistWorkspace();
}

function setupCardControls() {
  els.mainInput.value = state.text;
  els.copyInput.value = state.copyText;
  els.fontSize.value = String(state.fontSize);
  els.fontSizeValue.value = String(state.fontSize);
  els.fontSizeValue.textContent = String(state.fontSize);
  [els.themeGrid, els.fontOptions, els.ratioOptions, els.alignOptions].forEach(setupRovingRadio);

  els.mainInput.addEventListener("compositionstart", () => {
    isComposing = true;
  });
  els.mainInput.addEventListener("compositionend", (event) => {
    isComposing = false;
    setCardText(event.currentTarget.value);
  });
  els.mainInput.addEventListener("input", (event) => {
    if (!isComposing) setCardText(event.currentTarget.value);
  });

  els.copyInput.addEventListener("compositionstart", () => {
    isComposing = true;
  });
  els.copyInput.addEventListener("compositionend", (event) => {
    isComposing = false;
    state.copyText = event.currentTarget.value;
    syncCounts();
    updateStyleOutputs();
    persistWorkspace();
  });
  els.copyInput.addEventListener("input", (event) => {
    if (isComposing) return;
    state.copyText = event.currentTarget.value;
    syncCounts();
    updateStyleOutputs();
    persistWorkspace();
  });

  els.themeGrid.addEventListener("click", (event) => {
    const button = event.target.closest("[data-theme]");
    if (!button) return;
    state.theme = button.dataset.theme;
    updateRadioGroup(els.themeGrid, "theme", state.theme);
    renderCanvas();
    persistWorkspace();
  });

  els.fontOptions.addEventListener("click", (event) => {
    const button = event.target.closest("[data-font]");
    if (!button) return;
    state.font = button.dataset.font;
    updateRadioGroup(els.fontOptions, "font", state.font);
    renderCanvas();
    persistWorkspace();
  });

  els.ratioOptions.addEventListener("click", (event) => {
    const button = event.target.closest("[data-ratio]");
    if (!button) return;
    state.ratio = button.dataset.ratio;
    updateRadioGroup(els.ratioOptions, "ratio", state.ratio);
    renderCanvas();
    persistWorkspace();
  });

  els.alignOptions.addEventListener("click", (event) => {
    const button = event.target.closest("[data-align]");
    if (!button) return;
    state.align = button.dataset.align;
    updateRadioGroup(els.alignOptions, "align", state.align);
    renderCanvas();
    persistWorkspace();
  });

  els.fontSize.addEventListener("input", (event) => {
    state.fontSize = Number(event.currentTarget.value);
    els.fontSizeValue.value = String(state.fontSize);
    els.fontSizeValue.textContent = String(state.fontSize);
    renderCanvas();
    persistWorkspace();
  });

  $("#randomSample").addEventListener("click", () => {
    const options = SAMPLE_TEXTS.filter((text) => text !== state.text);
    const sample = options[Math.floor(Math.random() * options.length)];
    els.mainInput.value = sample;
    setCardText(sample);
    showToast("换了一句新的灵感");
  });

  $("#clearInput").addEventListener("click", () => {
    els.mainInput.value = "";
    setCardText("");
    els.mainInput.focus();
  });

  $("#syncFromCard").addEventListener("click", () => {
    state.copyText = state.text;
    els.copyInput.value = state.copyText;
    syncCounts();
    updateStyleOutputs();
    persistWorkspace();
    showToast("已带入图片文案");
  });
}

function setView(view, updateHash = true, focusHeading = false) {
  if (!["card", "copy", "saved"].includes(view)) view = "card";
  state.currentView = view;
  $$("[data-view-panel]").forEach((panel) => {
    const visible = panel.dataset.viewPanel === view;
    panel.hidden = !visible;
    panel.classList.toggle("is-visible", visible);
  });
  $$("[data-view]").forEach((button) => {
    const active = button.dataset.view === view;
    button.classList.toggle("is-active", active);
    if (active) button.setAttribute("aria-current", "page");
    else button.removeAttribute("aria-current");
  });
  els.mobileActionBar.hidden = view !== "card";
  if (view === "copy") updateStyleOutputs();
  if (view === "saved") renderSaved();
  if (updateHash) history.replaceState(null, "", "#" + view);
  const behavior = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
  window.scrollTo({ top: 0, behavior });
  if (focusHeading) {
    const heading = $(`[data-view-panel="${view}"] h1`);
    if (heading) {
      heading.tabIndex = -1;
      heading.focus({ preventScroll: true });
    }
  }
}

function setupNavigation() {
  $$("[data-view]").forEach((button) => {
    button.addEventListener("click", () => setView(button.dataset.view, true, true));
  });
  const hashView = location.hash.replace("#", "");
  setView(["card", "copy", "saved"].includes(hashView) ? hashView : "card", false);
  window.addEventListener("hashchange", () => setView(location.hash.replace("#", ""), false));
}

function renderCategoryFilters() {
  els.categoryFilters.replaceChildren();
  STYLE_CATEGORIES.forEach((category) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "filter-chip" + (state.activeCategory === category.id ? " is-selected" : "");
    button.dataset.category = category.id;
    const label = document.createElement("span");
    label.textContent = category.label;
    const count = document.createElement("span");
    count.className = "filter-count";
    count.textContent = String(stylesForCategory(category.id).length);
    count.setAttribute("aria-hidden", "true");
    button.append(label, count);
    button.setAttribute("aria-label", `${category.label}，${stylesForCategory(category.id).length} 款`);
    button.setAttribute("aria-pressed", String(state.activeCategory === category.id));
    button.tabIndex = state.activeCategory === category.id ? 0 : -1;
    els.categoryFilters.append(button);
  });
}

function updateCategoryFilters() {
  $$("[data-category]", els.categoryFilters).forEach((button) => {
    const selected = button.dataset.category === state.activeCategory;
    button.classList.toggle("is-selected", selected);
    button.setAttribute("aria-pressed", String(selected));
    button.tabIndex = selected ? 0 : -1;
  });
}

async function copyToClipboard(value) {
  hideToast();
  let copied = false;
  if (navigator.clipboard && window.isSecureContext) {
    try {
      await navigator.clipboard.writeText(value);
      copied = true;
    } catch {
      copied = false;
    }
  }
  if (!copied) {
    const textarea = document.createElement("textarea");
    textarea.value = value;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    textarea.style.pointerEvents = "none";
    document.body.append(textarea);
    textarea.select();
    textarea.setSelectionRange(0, value.length);
    try {
      copied = document.execCommand("copy");
    } catch {
      copied = false;
    }
    textarea.remove();
  }
  if (!copied) {
    window.prompt("请长按或按 Ctrl/Cmd + C 复制：", value);
    return false;
  }
  return true;
}

function addCopyHistory(styleId, value) {
  state.history = [
    { id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), styleId, value, createdAt: Date.now() },
    ...state.history.filter((item) => item.value !== value)
  ].slice(0, 20);
  persistWorkspace(true);
}

async function handleStyleCopy(styleId) {
  const value = stylizeText(state.copyText, styleId);
  if (!value) {
    showToast("先写一点文字吧");
    els.copyInput.focus();
    return;
  }
  const copied = await copyToClipboard(value);
  if (copied) {
    addCopyHistory(styleId, value);
    showToast("已复制，可粘贴到朋友圈");
  } else {
    showToast("未能自动复制，请在弹窗中手动复制");
  }
}

function toggleFavorite(styleId) {
  const index = state.favorites.indexOf(styleId);
  if (index >= 0) {
    state.favorites.splice(index, 1);
    showToast("已取消收藏");
  } else {
    state.favorites.unshift(styleId);
    showToast("已收藏这个花字");
  }
  updateFavoriteButtons();
  persistWorkspace(true);
}

function updateFavoriteButtons() {
  $$("[data-favorite-style]", els.styleGrid).forEach((button) => {
    const style = getStyle(button.dataset.favoriteStyle);
    const favorite = state.favorites.includes(style.id);
    button.classList.toggle("is-favorite", favorite);
    button.setAttribute("aria-label", favorite ? `取消收藏${style.name}` : `收藏${style.name}`);
    button.textContent = favorite ? "♥" : "♡";
  });
}

function updateStyleOutputs() {
  $$("[data-style-id]", els.styleGrid).forEach((button) => {
    const output = $(".style-output", button);
    if (output) output.textContent = stylizeText(state.copyText, button.dataset.styleId) || "输入文字后在这里预览";
  });
}

function renderStyles() {
  if (!els.styleGrid) return;
  els.styleGrid.replaceChildren();
  const styles = stylesForCategory(state.activeCategory);
  els.styleResultStatus.textContent = `已显示 ${styles.length} 款花字风格`;
  styles.forEach((style) => {
    const card = document.createElement("article");
    card.className = "style-card";

    const top = document.createElement("div");
    top.className = "style-card-top";
    const title = document.createElement("div");
    title.className = "style-card-title";
    const name = document.createElement("span");
    name.className = "style-card-name";
    name.textContent = style.name;
    title.append(name);
    if (style.original) {
      const original = document.createElement("span");
      original.className = "original-mark";
      original.textContent = "原创";
      title.append(original);
    }
    const favorite = document.createElement("button");
    favorite.type = "button";
    favorite.className = "favorite-button" + (state.favorites.includes(style.id) ? " is-favorite" : "");
    favorite.dataset.favoriteStyle = style.id;
    favorite.setAttribute("aria-label", state.favorites.includes(style.id) ? `取消收藏${style.name}` : `收藏${style.name}`);
    favorite.textContent = state.favorites.includes(style.id) ? "♥" : "♡";
    top.append(title, favorite);

    const copyButton = document.createElement("button");
    copyButton.type = "button";
    copyButton.className = "style-copy-button";
    copyButton.dataset.styleId = style.id;
    copyButton.setAttribute("aria-label", "复制" + style.name + "效果");

    const output = document.createElement("div");
    output.className = "style-output";
    output.textContent = stylizeText(state.copyText, style.id) || "输入文字后在这里预览";

    const bottom = document.createElement("div");
    bottom.className = "style-card-bottom";
    const badge = document.createElement("span");
    badge.className = "compat-badge " + style.compatibility;
    badge.textContent = style.hint;
    const copyCta = document.createElement("span");
    copyCta.className = "copy-cta";
    copyCta.textContent = "复制  ↗";
    bottom.append(badge, copyCta);

    copyButton.append(output, bottom);
    card.append(top, copyButton);
    els.styleGrid.append(card);
  });
}

function setupStyleLibrary() {
  els.categoryFilters.addEventListener("keydown", (event) => {
    const current = event.target.closest("[data-category]");
    if (!current) return;
    const buttons = $$("[data-category]", els.categoryFilters);
    const index = buttons.indexOf(current);
    let nextIndex = index;
    if (["ArrowRight", "ArrowDown"].includes(event.key)) nextIndex = (index + 1) % buttons.length;
    else if (["ArrowLeft", "ArrowUp"].includes(event.key)) nextIndex = (index - 1 + buttons.length) % buttons.length;
    else if (event.key === "Home") nextIndex = 0;
    else if (event.key === "End") nextIndex = buttons.length - 1;
    else return;
    event.preventDefault();
    buttons[nextIndex].focus();
    buttons[nextIndex].click();
  });

  els.categoryFilters.addEventListener("click", (event) => {
    const button = event.target.closest("[data-category]");
    if (!button) return;
    const nextCategory = button.dataset.category;
    if (state.activeCategory === nextCategory) return;
    state.activeCategory = nextCategory;
    updateCategoryFilters();
    renderStyles();
  });

  els.styleGrid.addEventListener("click", (event) => {
    const favorite = event.target.closest("[data-favorite-style]");
    if (favorite) {
      event.stopPropagation();
      toggleFavorite(favorite.dataset.favoriteStyle);
      return;
    }
    const card = event.target.closest("[data-style-id]");
    if (card) handleStyleCopy(card.dataset.styleId);
  });
}

function workSnapshot() {
  return {
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    text: state.text,
    theme: state.theme,
    font: state.font,
    ratio: state.ratio,
    fontSize: state.fontSize,
    align: state.align,
    background: { ...state.background },
    imageFit: state.imageFit,
    imageOpacity: state.imageOpacity,
    artElements: [...state.artElements],
    designDate: state.designDate,
    sealText: state.sealText,
    captionText: state.captionText,
    createdAt: Date.now()
  };
}

function workFingerprint(work) {
  return JSON.stringify({
    text: typeof work.text === "string" ? work.text : DEFAULT_TEXT,
    theme: THEMES.some((theme) => theme.id === work.theme) ? work.theme : "vermillion",
    font: FONT_OPTIONS[work.font] ? work.font : "song",
    ratio: RATIOS[work.ratio] ? work.ratio : "square",
    fontSize: Number.isFinite(work.fontSize) ? work.fontSize : 72,
    align: ["left", "center", "right"].includes(work.align) ? work.align : "center",
    background: normalizeBackground(work.background),
    imageFit: ["cover", "contain"].includes(work.imageFit) ? work.imageFit : "cover",
    imageOpacity: normalizeImageOpacity(work.imageOpacity),
    artElements: normalizeArtElements(work.artElements).sort(),
    designDate: /^\d{4}-\d{2}-\d{2}$/.test(work.designDate || "") ? work.designDate : todayInputValue(),
    sealText: sanitizeShortText(work.sealText, "花", 2),
    captionText: sanitizeShortText(work.captionText, "愿你自在生长", 24)
  });
}

function saveCurrentWork(showMessage = true) {
  if (!state.text.trim()) {
    showToast("先写一点文字吧");
    els.mainInput.focus();
    return false;
  }
  if (activeUploadToken) {
    if (showMessage) showToast("图片还在处理中，请稍候再保存");
    return false;
  }
  if (state.background.type === "image" && !state.background.imageId) {
    if (showMessage) showToast("浏览器未能保存这张背景图；可以先导出，或重新选择后再存作品");
    return false;
  }
  const latest = state.works[0];
  const snapshot = workSnapshot();
  if (latest && workFingerprint(latest) === workFingerprint(snapshot)) {
    if (showMessage) showToast("这份作品已经保存过了");
    return true;
  }
  state.works.unshift(snapshot);
  state.works = state.works.slice(0, 18);
  persistWorkspace(true);
  void pruneUnusedMedia();
  if (showMessage) showToast("已存到“我的作品”");
  return true;
}

async function loadWork(work) {
  const normalized = JSON.parse(workFingerprint(work));
  clearActiveBackgroundImage();
  state.text = normalized.text;
  state.theme = normalized.theme;
  state.font = normalized.font;
  state.ratio = normalized.ratio;
  state.fontSize = normalized.fontSize;
  state.align = normalized.align;
  state.background = normalized.background;
  state.imageFit = normalized.imageFit;
  state.imageOpacity = normalized.imageOpacity;
  state.artElements = normalized.artElements;
  state.designDate = normalized.designDate;
  state.sealText = normalized.sealText;
  state.captionText = normalized.captionText;
  els.mainInput.value = state.text;
  els.fontSize.value = String(state.fontSize);
  els.fontSizeValue.value = String(state.fontSize);
  els.fontSizeValue.textContent = String(state.fontSize);
  updateRadioGroup(els.themeGrid, "theme", state.theme);
  updateRadioGroup(els.fontOptions, "font", state.font);
  updateRadioGroup(els.ratioOptions, "ratio", state.ratio);
  updateRadioGroup(els.alignOptions, "align", state.align);
  syncDiyControls();
  syncCounts();
  renderCanvas();
  setView("card");
  let backgroundFound = true;
  let loadToken = backgroundLoadToken;
  if (state.background.type === "image") {
    const loading = activateBackgroundImage(state.background.imageId, { silent: true });
    loadToken = backgroundLoadToken;
    backgroundFound = await loading;
  }
  if (loadToken !== backgroundLoadToken) return;
  persistWorkspace(true);
  showToast(backgroundFound ? "作品已打开，可以继续编辑" : "作品已打开，原背景图需要重新选择");
}

function renderSaved() {
  els.worksGrid.replaceChildren();
  els.favoritesList.replaceChildren();
  els.worksCount.textContent = state.works.length + " 个";
  els.favoritesCount.textContent = state.favorites.length + " 个";

  if (!state.works.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "还没有卡片作品。做好一张以后点“存作品”就会出现在这里。";
    els.worksGrid.append(empty);
  } else {
    state.works.forEach((work) => {
      const theme = THEMES.find((item) => item.id === work.theme) || THEMES[0];
      const card = document.createElement("article");
      card.className = "work-card";
      card.dataset.workId = work.id;
      const preview = document.createElement("button");
      preview.type = "button";
      preview.className = "work-card-preview";
      preview.dataset.openWork = work.id;
      preview.setAttribute("aria-label", "打开这份作品");
      preview.style.setProperty("--preview-bg", theme.background[0]);
      preview.style.setProperty("--preview-fg", theme.foreground);
      preview.style.setProperty("--preview-font", FONT_OPTIONS[work.font]?.stack || FONT_OPTIONS.song.stack);
      preview.textContent = work.text;

      const meta = document.createElement("div");
      meta.className = "work-card-meta";
      const title = document.createElement("strong");
      title.textContent = work.background?.type === "image" ? `${theme.name} · 自选图片` : theme.name;
      const date = document.createElement("span");
      date.textContent = new Intl.DateTimeFormat("zh-CN", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(work.createdAt);
      meta.append(title, date);

      const remove = document.createElement("button");
      remove.type = "button";
      remove.dataset.deleteWork = work.id;
      remove.setAttribute("aria-label", "删除这份作品");
      remove.textContent = "×";
      card.append(preview, meta, remove);
      els.worksGrid.append(card);
    });
  }

  if (!state.favorites.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "花字卡片右上角的 ♡ 可以收藏常用款式。";
    els.favoritesList.append(empty);
  } else {
    state.favorites.forEach((styleId) => {
      const style = getStyle(styleId);
      const row = document.createElement("div");
      row.className = "favorite-row";
      const content = document.createElement("div");
      const name = document.createElement("strong");
      name.textContent = style.name;
      const preview = document.createElement("span");
      preview.textContent = stylizeText(state.copyText, style.id);
      content.append(name, preview);
      const copy = document.createElement("button");
      copy.type = "button";
      copy.dataset.copyFavorite = style.id;
      copy.textContent = "复制";
      row.append(content, copy);
      els.favoritesList.append(row);
    });
  }
}

function setupSaved() {
  els.worksGrid.addEventListener("click", (event) => {
    const open = event.target.closest("[data-open-work]");
    if (open) {
      const work = state.works.find((item) => item.id === open.dataset.openWork);
      if (work) void loadWork(work);
      return;
    }
    const remove = event.target.closest("[data-delete-work]");
    if (!remove) return;
    const work = state.works.find((item) => item.id === remove.dataset.deleteWork);
    if (!work) return;
    if (window.confirm("要删除这份本地作品吗？")) {
      state.works = state.works.filter((item) => item.id !== work.id);
      persistWorkspace(true);
      renderSaved();
      void pruneUnusedMedia();
      showToast("作品已删除");
    }
  });

  els.favoritesList.addEventListener("click", (event) => {
    const button = event.target.closest("[data-copy-favorite]");
    if (button) handleStyleCopy(button.dataset.copyFavorite);
  });

  $("#clearLocalData").addEventListener("click", () => {
    if (!window.confirm("要清空本机的作品、收藏和复制记录吗？当前编辑文字会保留。")) return;
    state.works = [];
    state.favorites = [];
    state.history = [];
    persistWorkspace(true);
    renderSaved();
    updateFavoriteButtons();
    void pruneUnusedMedia();
    showToast("本地记录已清理");
  });
}

function canvasBlob() {
  return new Promise((resolve, reject) => {
    els.canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error("PNG export failed"));
    }, "image/png", 1);
  });
}

async function prepareExport() {
  if (!state.text.trim()) {
    showToast("先写一点文字吧");
    els.mainInput.focus();
    return;
  }
  const exportButtons = [$("#exportImage"), $("#mobileExportImage")];
  exportButtons.forEach((button) => {
    button.disabled = true;
    button.textContent = "正在生成…";
  });
  try {
    if (document.fonts?.ready) await document.fonts.ready;
    let pendingBackground;
    do {
      pendingBackground = backgroundReadyPromise;
      await pendingBackground;
    } while (pendingBackground !== backgroundReadyPromise);
    renderCanvas();
    if (canvasOverflow) {
      showToast("文字行数太多，请减少换行后再导出");
      els.mainInput.focus();
      return;
    }
    currentExportBlob = await canvasBlob();
    if (exportObjectUrl) URL.revokeObjectURL(exportObjectUrl);
    exportObjectUrl = URL.createObjectURL(currentExportBlob);
    els.exportPreview.src = exportObjectUrl;
    const exportFile = new File([currentExportBlob], exportFilename(), { type: "image/png" });
    let canShareFiles = false;
    try {
      canShareFiles = Boolean(navigator.share && (!navigator.canShare || navigator.canShare({ files: [exportFile] })));
    } catch {
      canShareFiles = false;
    }
    const shareButton = $("#shareImage");
    const downloadButton = $("#downloadImage");
    const dialogActions = $(".dialog-actions", els.exportDialog);
    const dialogNote = $(".dialog-heading p", els.exportDialog);
    const touchSave = isIOSLike() || isWeChatBrowser();
    shareButton.hidden = !canShareFiles;
    dialogActions.classList.toggle("single-action", !canShareFiles);
    downloadButton.textContent = touchSave ? "打开 / 保存 PNG" : "下载 PNG";
    dialogNote.textContent = isWeChatBrowser()
      ? "请长按下方图片保存；如果菜单没有出现，可以先在系统浏览器打开。"
      : isIOSLike()
        ? "可以使用系统分享存储到照片，也可以长按下方图片保存。"
        : "可以直接下载 PNG；浏览器支持时也可唤起系统分享。";
    saveCurrentWork(false);
    els.exportDialog.showModal();
  } catch {
    showToast("图片生成失败，请刷新后再试");
  } finally {
    $("#exportImage").disabled = false;
    $("#exportImage").innerHTML = '<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M12 4v11m0 0 4-4m-4 4-4-4M5 19h14"></path></svg>导出 / 分享';
    $("#mobileExportImage").disabled = false;
    $("#mobileExportImage").textContent = "导出 / 分享";
  }
}

function exportFilename() {
  const date = new Date();
  const stamp =
    date.getFullYear() +
    String(date.getMonth() + 1).padStart(2, "0") +
    String(date.getDate()).padStart(2, "0") +
    "-" +
    String(date.getHours()).padStart(2, "0") +
    String(date.getMinutes()).padStart(2, "0");
  return "花漾字-" + stamp + ".png";
}

function downloadCurrentExport() {
  if (!currentExportBlob || !exportObjectUrl) return;
  const link = document.createElement("a");
  link.href = exportObjectUrl;
  link.download = exportFilename();
  document.body.append(link);
  link.click();
  link.remove();
  showToast(
    isIOSLike() || isWeChatBrowser()
      ? "如未自动保存，请长按预览图选择保存图片"
      : "已开始下载 PNG"
  );
}

async function shareCurrentExport() {
  if (!currentExportBlob) return;
  const file = new File([currentExportBlob], exportFilename(), { type: "image/png" });
  if (navigator.share && (!navigator.canShare || navigator.canShare({ files: [file] }))) {
    try {
      await navigator.share({
        title: "花漾字作品",
        text: state.text,
        files: [file]
      });
      return;
    } catch (error) {
      if (error?.name === "AbortError") return;
    }
  }
  downloadCurrentExport();
  showToast(
    isIOSLike() || isWeChatBrowser()
      ? "系统分享暂不可用，请长按预览图保存"
      : "系统分享暂不可用，已尝试下载 PNG"
  );
}

function setupExport() {
  ["#exportImage", "#mobileExportImage", "#fullscreenPreview"].forEach((selector) => {
    $(selector).addEventListener("click", prepareExport);
  });
  ["#saveDraft", "#mobileSaveDraft"].forEach((selector) => {
    $(selector).addEventListener("click", () => saveCurrentWork(true));
  });
  $("#downloadImage").addEventListener("click", downloadCurrentExport);
  $("#shareImage").addEventListener("click", shareCurrentExport);
}

function isIOSLike() {
  return (
    /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1)
  );
}

function isAndroidLike() {
  return /Android/i.test(navigator.userAgent);
}

function isWeChatBrowser() {
  return /MicroMessenger/i.test(navigator.userAgent);
}

function renderInstallSteps(platform) {
  els.installSteps.replaceChildren();
  INSTALL_STEPS[platform].forEach((step) => {
    const item = document.createElement("li");
    item.textContent = step;
    els.installSteps.append(item);
  });
  $$("[data-install-tab]").forEach((button) => {
    const selected = button.dataset.installTab === platform;
    button.classList.toggle("is-selected", selected);
    button.setAttribute("aria-selected", String(selected));
  });
}

function showInstallGuide() {
  const platform = isIOSLike() ? "ios" : isAndroidLike() ? "android" : "windows";
  renderInstallSteps(platform);
  els.installDialog.showModal();
}

async function handleInstall() {
  if (deferredInstallPrompt) {
    deferredInstallPrompt.prompt();
    const result = await deferredInstallPrompt.userChoice;
    if (result.outcome === "accepted") showToast("花漾字正在安装");
    deferredInstallPrompt = null;
  } else {
    showInstallGuide();
  }
}

function setupInstall() {
  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    deferredInstallPrompt = event;
  });
  $("#installButton").addEventListener("click", handleInstall);
  $("#installGuideButton").addEventListener("click", handleInstall);
  $$("[data-install-tab]").forEach((button) => {
    button.addEventListener("click", () => renderInstallSteps(button.dataset.installTab));
  });
  window.addEventListener("appinstalled", () => {
    deferredInstallPrompt = null;
    showToast("花漾字已安装到设备");
  });
}

function setupViewportBehavior() {
  if (!window.visualViewport) return;
  const update = () => {
    const viewport = window.visualViewport;
    const keyboardOpen = window.innerHeight - viewport.height - viewport.offsetTop > 160;
    document.body.classList.toggle("keyboard-open", keyboardOpen);
    document.documentElement.style.setProperty("--visual-offset-top", viewport.offsetTop + "px");
  };
  window.visualViewport.addEventListener("resize", update);
  window.visualViewport.addEventListener("scroll", update);
  window.addEventListener("orientationchange", update);
  update();
}

function setupKeyboardShortcuts() {
  window.addEventListener("keydown", (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key === "Enter" && state.currentView === "card") {
      event.preventDefault();
      prepareExport();
    }
  });
}

function setupConnectivity() {
  window.addEventListener("offline", () => showToast("已进入离线模式，核心功能仍可使用"));
  window.addEventListener("online", () => showToast("网络已恢复"));
}

async function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) return;
  try {
    const registration = await navigator.serviceWorker.register("./sw.js", { scope: "./" });
    registration.addEventListener("updatefound", () => {
      const worker = registration.installing;
      worker?.addEventListener("statechange", () => {
        if (worker.state === "installed" && navigator.serviceWorker.controller) {
          showToast("新版本已准备好，下次打开即可使用");
        }
      });
    });
  } catch {
    console.info("离线缓存暂不可用");
  }
}

async function init() {
  renderThemeGrid();
  updateRadioGroup(els.themeGrid, "theme", state.theme);
  updateRadioGroup(els.fontOptions, "font", state.font);
  updateRadioGroup(els.ratioOptions, "ratio", state.ratio);
  updateRadioGroup(els.alignOptions, "align", state.align);
  setupCardControls();
  setupDiyControls();
  setupNavigation();
  setupStyleLibrary();
  setupSaved();
  setupExport();
  setupInstall();
  setupViewportBehavior();
  setupKeyboardShortcuts();
  setupConnectivity();
  syncCounts();
  renderCanvas();
  renderCategoryFilters();
  renderStyles();
  renderSaved();
  if (state.background.type === "image") {
    await activateBackgroundImage(state.background.imageId, { silent: true });
  }
  persistWorkspace(true);
  registerServiceWorker();
}

void init();
